from django.shortcuts import render

def Home(reqest):
    return render(reqest ,"home.html")

def Add(reqest):
   
    val1=reqest.GET.get('val1')
    val2=reqest.GET.get('val2')
    operater = reqest.GET.get('op')
    sum = 0
    if operater == "+":
        sum = int(val1) + int(val2)
    elif operater == "*":
        sum == int(val1) * int(val2)
    dic = {'sum' : sum , 'val1':val1 , 'val2':val2}
    return render(reqest ,"home.html" , dic)